public class Desafiador4 {
    public static void main(String[] args) {
        double[][] notas = {
                {7.5, 8.0},
                {6.0, 7.0},
                {9.0, 8.5},
                {5.5, 6.0},
                {8.0, 7.5}
        };

        for (int i = 0; i < notas.length; i++) {
            double soma = 0;
            for (int j = 0; j < notas[i].length; j++) {
                soma += notas[i][j];
            }
            double media = soma / notas[i].length;
            System.out.printf("Aluno %d: Média = %.2f%n", i + 1, media);
        }
    }
}
