import java.util.HashSet;
import java.util.Random;
import java.util.Scanner;
import java.util.Set;

public class Desafiador5 {

    public static void main(String[] args) {
        char[][] tabuleiro = new char[7][7];
        for (int i = 0; i < 7; i++) {
            for (int j = 0; j < 7; j++) {
                tabuleiro[i][j] = '-';
            }
        }

        Set<String> navios = new HashSet<>();
        Random rand = new Random();

        while (navios.size() < 3) {
            int linha = rand.nextInt(7);
            int coluna = rand.nextInt(7);
            navios.add(linha + "," + coluna);
        }

        Scanner scanner = new Scanner(System.in);
        int acertos = 0;

        System.out.println("Bem-vindo à Batalha Naval Simplificada!");
        mostrarTabuleiro(tabuleiro);

        while (acertos < 3) {
            System.out.print("Digite a linha (0 a 6): ");
            int linha = scanner.nextInt();

            System.out.print("Digite a coluna (0 a 6): ");
            int coluna = scanner.nextInt();

            if (linha < 0 || linha > 6 || coluna < 0 || coluna > 6) {
                System.out.println("Coordenadas inválidas. Tente novamente.");
                continue;
            }

            if (tabuleiro[linha][coluna] != '-') {
                System.out.println("Você já tentou essa posição. Escolha outra.");
                continue;
            }

            String pos = linha + "," + coluna;

            if (navios.contains(pos)) {
                System.out.println("Acertou um navio!");
                tabuleiro[linha][coluna] = 'X';
                acertos++;
            } else {
                System.out.println("Água...");
                tabuleiro[linha][coluna] = 'O';
            }

            mostrarTabuleiro(tabuleiro);
        }

        System.out.println("Parabéns! Você encontrou todos os navios!");
        scanner.close();
    }
    public static void mostrarTabuleiro(char[][] tabuleiro) {
        System.out.print("  ");
        for (int i = 0; i < 7; i++) {
            System.out.print(i + " ");
        }
        System.out.println();

        for (int i = 0; i < 7; i++) {
            System.out.print(i + " ");
            for (int j = 0; j < 7; j++) {
                System.out.print(tabuleiro[i][j] + " ");
            }
            System.out.println();
        }
    }
}
