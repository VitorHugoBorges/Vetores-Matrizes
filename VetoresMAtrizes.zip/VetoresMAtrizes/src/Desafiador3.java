import java.util.Scanner;

public class Desafiador3 {
    public static void main(String[] args) {
        char[][] tabuleiro = new char[3][3];
        inicializarTabuleiro(tabuleiro);

        Scanner scanner = new Scanner(System.in);
        char jogadorAtual = 'X';
        int jogadas = 0;

        while (jogadas < 9) {
            exibirTabuleiro(tabuleiro);
            System.out.println("Jogador " + jogadorAtual + ", escolha sua jogada.");

            int linha, coluna;
            while (true) {
                System.out.print("Linha (0-2): ");
                linha = scanner.nextInt();
                System.out.print("Coluna (0-2): ");
                coluna = scanner.nextInt();

                if (linha >= 0 && linha < 3 && coluna >= 0 && coluna < 3) {
                    if (tabuleiro[linha][coluna] == ' ') {
                        tabuleiro[linha][coluna] = jogadorAtual;
                        jogadas++;
                        break;
                    } else {
                        System.out.println("Posição já ocupada! Tente outra.");
                    }
                } else {
                    System.out.println("Posição inválida. Tente novamente.");
                }
            }

            jogadorAtual = (jogadorAtual == 'X') ? 'O' : 'X';
        }

        exibirTabuleiro(tabuleiro);
        System.out.println("Jogo encerrado!");
        scanner.close();
    }

    public static void inicializarTabuleiro(char[][] tabuleiro) {
        for (int i = 0; i < 3; i++) {
            for (int j = 0; j < 3; j++) {
                tabuleiro[i][j] = ' ';
            }
        }
    }

    public static void exibirTabuleiro(char[][] tabuleiro) {
        System.out.println("  0 1 2");
        for (int i = 0; i < 3; i++) {
            System.out.print(i + " ");
            for (int j = 0; j < 3; j++) {
                System.out.print(tabuleiro[i][j]);
                if (j < 2) System.out.print("|");
            }
            System.out.println();
            if (i < 2) System.out.println("  -----");
        }
    }
}

