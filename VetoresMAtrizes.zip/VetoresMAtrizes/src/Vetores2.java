import java.util.Random;

public class Vetores2 {
    public static void main(String[] args) {
        Random random = new Random();
        int[] numeros = new int[15];

        for (int i = 0; i < numeros.length; i++) {
            numeros[i] = random.nextInt(100) + 1;
        }

        System.out.print("Números gerados: ");
        for (int num : numeros) {
            System.out.print(num + " ");
        }
        System.out.println();

        System.out.print("Números pares: ");
        for (int num : numeros) {
            if (num % 2 == 0) {
                System.out.print(num + " ");
            }
        }
        System.out.println();

        System.out.print("Números ímpares: ");
        for (int num : numeros) {
            if (num % 2 != 0) {
                System.out.print(num + " ");
            }
        }
        System.out.println();
    }
}
